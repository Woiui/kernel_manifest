#!/system/bin/sh

MODDIR=${0%/*}

#lz4kd
sleep 30
su -c insmod $MODDIR/zram/zstdn.ko
su -c swapoff /dev/block/zram0
su -c rmmod zram
sleep 5
su -c insmod $MODDIR/zram/zram.ko
sleep 5
echo '1' > /sys/block/zram0/reset
echo '0' > /sys/block/zram0/disksize
echo '8' > /sys/block/zram0/max_comp_streams
echo 'lz4kd' >/sys/block/zram0/comp_algorithm
echo '17179869184' > /sys/block/zram0/disksize
mkswap /dev/block/zram0 > /dev/null 2>&1
swapon /dev/block/zram0 > /dev/null 2>&1